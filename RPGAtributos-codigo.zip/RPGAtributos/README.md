# RPGAtributos

Plugin para **Paper 26.3** (Minecraft 26.3, Java 25) com atributos estilo RPG que evoluem com o uso, item na cabeça e tag personalizada.

## O que ele faz

| Atributo | Como ganha XP | O que melhora (no nível 50, padrão) |
|---|---|---|
| ⛏ Mineração | Quebrar blocos de picareta (minério vale mais) | +100% velocidade de mineração, 50% de chance de minério em dobro |
| ♣ Corte de Madeira | Quebrar troncos | +100% velocidade no tronco, 50% de chance de tronco em dobro |
| » Corrida | Correr (sprint) | +20% velocidade de movimento |
| ⬆ Pulo e Queda | Pular e levar dano de queda | +30% altura do pulo, +5 blocos de queda segura, -50% dano de queda |
| ⚔ Combate | Matar mobs e jogadores | +2,5 de dano, +5 corações |

Tudo é ajustável no `config.yml`. Os bônus usam os **atributos nativos** do Minecraft, então funcionam liso, sem gambiarra.

**Anti-farm:** blocos colocados por jogadores não dão XP; mobs de spawner dão só 25% do XP; criativo não ganha XP.

**Menu (interface):** `/atributos` abre uma janela de baú com um ícone por atributo. Passando o mouse você vê nível, barra de progresso, XP que falta, bônus atual, bônus do próximo nível e como evoluir. Atributos no nível máximo brilham. O botão **✦ Cosméticos** abre a segunda tela:
- clique em **qualquer item do seu inventário** para colocá-lo na cabeça;
- clique no item que está na cabeça para tirá-lo;
- clique na **etiqueta** e digite a nova tag no chat (ou `cancelar`);
- o corante vermelho remove a tag.

Nada pode ser roubado do menu: todos os ícones são só botões.

**Cosméticos por comando (atalhos):**
- `/chapeu` coloca o item da mão na cabeça (picareta, bloco, qualquer coisa). `/chapeu tirar` devolve.
- `/tag &6Rei &fdo Minério` troca o texto em cima da cabeça (aceita cores com `&`). `/tag remover` volta ao nome normal.
- Com `tag.mostrar-nivel: true`, todo mundo mostra "Nível total X" embaixo do nome.

Os dados ficam salvos dentro do arquivo do próprio jogador: não precisa de banco de dados.

## Comandos

| Comando | Quem pode | O que faz |
|---|---|---|
| `/atributos [jogador]` | todos | Abre o menu de atributos (`/atributos <jogador> chat` mostra no chat) |
| `/cosmeticos` | todos | Abre direto o menu de cosméticos |
| `/chapeu [tirar]` | todos | Item da mão na cabeça |
| `/tag <texto>` / `/tag remover` | todos | Tag em cima da cabeça |
| `/rpgadmin set <jogador> <atributo> <nível>` | OP | Define o nível |
| `/rpgadmin addxp <jogador> <atributo> <xp>` | OP | Dá XP |
| `/rpgadmin reset <jogador> [atributo]` | OP | Zera |
| `/rpgadmin reload` | OP | Recarrega o config |

Atributos: `mineracao`, `madeira`, `corrida`, `pulo`, `combate`.

Permissões: `rpg.atributos`, `rpg.atributos.outros`, `rpg.chapeu`, `rpg.tag`, `rpg.tag.cores` (todos liberados por padrão) e `rpg.admin` (só OP).

## Como gerar o .jar

Escolha **um** dos jeitos:

### Jeito 1: pelo GitHub (não precisa instalar nada)
1. Crie um repositório no GitHub e suba esta pasta inteira (inclusive a pasta `.github`).
2. Abra a aba **Actions**: a compilação roda sozinha em ~1 minuto.
3. Clique na execução concluída e baixe **RPGAtributos** em *Artifacts*. Dentro do zip está o `.jar`.

### Jeito 2: no seu PC
1. Instale o **Java 25** (JDK, ex.: Adoptium Temurin) e o **Maven**.
2. Abra o terminal nesta pasta e rode:
   ```
   mvn package
   ```
3. O plugin fica em `target/RPGAtributos-1.0.0.jar`.

(No IntelliJ IDEA: *Open* na pasta → se pedir JDK, baixe o **25** → aba Maven → *Lifecycle* → *package*.)

## Instalar
Coloque o `.jar` na pasta `plugins/` do servidor Paper 26.3 e reinicie. O `config.yml` aparece em `plugins/RPGAtributos/`.

## Bom saber
- A tag usa um time de scoreboard para esconder o nome normal. Se você usar outro plugin que mexe em times de nametag (ex.: TAB), os dois podem brigar. Nesse caso, desative a parte de nametag de um deles.
- A memória de "bloco colocado por jogador" zera quando o servidor reinicia.
- Troca de skin não está nesta versão; dá pra adicionar depois (via SkinsRestorer ou API de perfil do Paper).
