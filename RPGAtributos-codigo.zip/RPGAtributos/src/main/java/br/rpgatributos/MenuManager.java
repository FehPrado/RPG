package br.rpgatributos;

import com.google.common.collect.ImmutableMultimap;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Menus de baú: tela de atributos e tela de cosméticos (chapéu e tag).
 * Nenhum item pode ser tirado dos menus; tudo é botão.
 */
public final class MenuManager implements Listener {

    private enum Tipo { PRINCIPAL, COSMETICOS }

    /** Marca um inventário como menu nosso. */
    private static final class Menu implements InventoryHolder {
        final Tipo tipo;
        final UUID alvo;
        Inventory inventario;

        Menu(Tipo tipo, UUID alvo) {
            this.tipo = tipo;
            this.alvo = alvo;
        }

        @Override
        public Inventory getInventory() { return inventario; }
    }

    // ----- posições no menu principal (5 linhas) -----
    private static final int P_CABECA = 4;
    private static final int[] P_SKILLS = {20, 21, 22, 23, 24};
    private static final int P_COSMETICOS = 39;
    private static final int P_FECHAR = 41;

    // ----- posições no menu de cosméticos (4 linhas) -----
    private static final int C_DICA_CHAPEU = 10;
    private static final int C_CHAPEU_ATUAL = 11;
    private static final int C_TAG_ATUAL = 15;
    private static final int C_TAG_REMOVER = 16;
    private static final int C_VOLTAR = 31;

    private static final long TEMPO_PARA_DIGITAR_MS = 60_000;

    private final RPGAtributos plugin;
    /** Jogadores que clicaram em "trocar tag" e estão digitando no chat (UUID → expira em). */
    private final Map<UUID, Long> esperandoTag = new ConcurrentHashMap<>();

    public MenuManager(RPGAtributos plugin) {
        this.plugin = plugin;
    }

    // =====================================================================
    //  Abrir menus
    // =====================================================================

    public void abrirPrincipal(Player quemVe, Player alvo) {
        Menu menu = new Menu(Tipo.PRINCIPAL, alvo.getUniqueId());
        boolean proprio = quemVe.equals(alvo);
        Component titulo = Component.text(proprio ? "Seus Atributos" : "Atributos de " + alvo.getName());
        Inventory inv = Bukkit.createInventory(menu, 45, titulo);
        menu.inventario = inv;

        StatsManager st = plugin.stats();
        int max = plugin.settings().nivelMaximo;

        // Cabeça do jogador com o resumo
        ItemStack cabeca = new ItemStack(Material.PLAYER_HEAD);
        cabeca.editMeta(SkullMeta.class, m -> m.setOwningPlayer(alvo));
        List<Component> resumo = new ArrayList<>();
        resumo.add(linha("Nível total: ", NamedTextColor.GRAY, String.valueOf(st.nivelTotal(alvo)), NamedTextColor.YELLOW));
        resumo.add(Component.empty());
        for (Skill s : Skill.values()) {
            resumo.add(Component.text(s.icone() + " " + s.nome() + ": ", s.cor())
                    .append(Component.text("Nv " + st.getNivel(alvo, s), NamedTextColor.WHITE)));
        }
        String tag = plugin.tags().getTag(alvo);
        if (tag != null) {
            resumo.add(Component.empty());
            resumo.add(Component.text("Tag: ", NamedTextColor.GRAY).append(LegacyComponentSerializer.legacyAmpersand().deserialize(tag)));
        }
        inv.setItem(P_CABECA, enfeitar(cabeca, Component.text(alvo.getName(), NamedTextColor.GOLD, TextDecoration.BOLD), resumo, false));

        // Um ícone por atributo
        Skill[] skills = Skill.values();
        for (int i = 0; i < skills.length && i < P_SKILLS.length; i++) {
            inv.setItem(P_SKILLS[i], iconeSkill(alvo, skills[i], max));
        }

        if (proprio && (quemVe.hasPermission("rpg.chapeu") || quemVe.hasPermission("rpg.tag"))) {
            inv.setItem(P_COSMETICOS, item(Material.LEATHER_HELMET,
                    Component.text("✦ Cosméticos", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD),
                    List.of(Component.text("Item na cabeça e tag personalizada.", NamedTextColor.GRAY),
                            Component.empty(),
                            Component.text("» Clique para abrir", NamedTextColor.YELLOW))));
        }
        inv.setItem(P_FECHAR, item(Material.BARRIER, Component.text("Fechar", NamedTextColor.RED), List.of()));

        preencherBorda(inv);
        quemVe.openInventory(inv);
    }

    public void abrirCosmeticos(Player p) {
        Menu menu = new Menu(Tipo.COSMETICOS, p.getUniqueId());
        Inventory inv = Bukkit.createInventory(menu, 36, Component.text("Cosméticos"));
        menu.inventario = inv;
        desenharCosmeticos(inv, p);
        p.openInventory(inv);
    }

    private void desenharCosmeticos(Inventory inv, Player p) {
        inv.clear();

        // --- chapéu ---
        inv.setItem(C_DICA_CHAPEU, item(Material.OAK_SIGN,
                Component.text("Item na cabeça", NamedTextColor.GOLD, TextDecoration.BOLD),
                List.of(Component.text("Clique em qualquer item do", NamedTextColor.GRAY),
                        Component.text("SEU inventário (aqui embaixo)", NamedTextColor.WHITE),
                        Component.text("para colocá-lo na cabeça.", NamedTextColor.GRAY),
                        Component.empty(),
                        Component.text("Vale tudo: picareta, bloco, flor...", NamedTextColor.DARK_GRAY))));

        ItemStack capacete = p.getInventory().getHelmet();
        if (capacete == null || capacete.isEmpty()) {
            inv.setItem(C_CHAPEU_ATUAL, item(Material.GLASS,
                    Component.text("Nada na cabeça", NamedTextColor.GRAY),
                    List.of(Component.text("Escolha um item lá embaixo.", NamedTextColor.DARK_GRAY))));
        } else {
            ItemStack mostra = capacete.clone();
            List<Component> lore = new ArrayList<>();
            lore.add(Component.text("Está na sua cabeça agora.", NamedTextColor.GRAY));
            lore.add(Component.empty());
            lore.add(Component.text("» Clique para tirar", NamedTextColor.YELLOW));
            mostra.editMeta(m -> m.lore(semItalico(lore)));
            inv.setItem(C_CHAPEU_ATUAL, mostra);
        }

        // --- tag ---
        String tag = plugin.tags().getTag(p);
        Component tagAtual = tag == null
                ? Component.text(p.getName() + " (padrão)", NamedTextColor.WHITE)
                : LegacyComponentSerializer.legacyAmpersand().deserialize(tag);
        inv.setItem(C_TAG_ATUAL, item(Material.NAME_TAG,
                Component.text("Trocar tag", NamedTextColor.AQUA, TextDecoration.BOLD),
                List.of(Component.text("Atual: ", NamedTextColor.GRAY).append(tagAtual),
                        Component.empty(),
                        Component.text("Cores com &: &6dourado &cvermelho &averde", NamedTextColor.DARK_GRAY),
                        Component.empty(),
                        Component.text("» Clique e digite no chat", NamedTextColor.YELLOW))));
        if (tag != null) {
            inv.setItem(C_TAG_REMOVER, item(Material.RED_DYE,
                    Component.text("Remover tag", NamedTextColor.RED),
                    List.of(Component.text("Volta a mostrar seu nome normal.", NamedTextColor.GRAY))));
        }

        inv.setItem(C_VOLTAR, item(Material.ARROW, Component.text("« Voltar", NamedTextColor.YELLOW), List.of()));
        preencherBorda(inv);
    }

    // =====================================================================
    //  Cliques
    // =====================================================================

    @EventHandler(priority = EventPriority.HIGH)
    public void aoClicar(InventoryClickEvent e) {
        Inventory topo = e.getView().getTopInventory();
        if (!(topo.getHolder(false) instanceof Menu menu)) return;
        e.setCancelled(true); // nada sai nem entra no menu
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null) return;

        boolean clicouNoMenu = e.getRawSlot() < topo.getSize();
        int slot = e.getSlot();

        if (menu.tipo == Tipo.PRINCIPAL) {
            if (!clicouNoMenu) return;
            if (slot == P_FECHAR) {
                p.closeInventory();
            } else if (slot == P_COSMETICOS && topo.getItem(slot) != null
                    && topo.getItem(slot).getType() == Material.LEATHER_HELMET) {
                clique(p);
                abrirCosmeticos(p);
            }
            return;
        }

        // ----- cosméticos -----
        if (!clicouNoMenu) {
            // Clicou num item do próprio inventário: vai para a cabeça.
            if (!p.hasPermission("rpg.chapeu")) { erro(p, "Sem permissão."); return; }
            if (e.getCurrentItem() == null || e.getCurrentItem().isEmpty()) return;
            Chapeu.Resultado r = Chapeu.colocar(p, slot);
            if (!r.ok()) erro(p, r.mensagem());
            desenharCosmeticos(topo, p);
            return;
        }

        switch (slot) {
            case C_CHAPEU_ATUAL -> {
                ItemStack capacete = p.getInventory().getHelmet();
                if (capacete != null && !capacete.isEmpty()) {
                    Chapeu.Resultado r = Chapeu.tirar(p);
                    if (!r.ok()) erro(p, r.mensagem());
                    desenharCosmeticos(topo, p);
                }
            }
            case C_TAG_ATUAL -> {
                if (!p.hasPermission("rpg.tag")) { erro(p, "Sem permissão."); return; }
                esperandoTag.put(p.getUniqueId(), System.currentTimeMillis() + TEMPO_PARA_DIGITAR_MS);
                p.closeInventory();
                clique(p);
                p.sendMessage(Component.text("✎ Digite sua nova tag no chat.", NamedTextColor.AQUA));
                p.sendMessage(Component.text("  Use & para cores (ex: &6Rei &fdo Minério). Digite ", NamedTextColor.GRAY)
                        .append(Component.text("cancelar", NamedTextColor.RED))
                        .append(Component.text(" para desistir.", NamedTextColor.GRAY)));
            }
            case C_TAG_REMOVER -> {
                if (plugin.tags().getTag(p) != null) {
                    plugin.tags().setTag(p, null);
                    clique(p);
                    desenharCosmeticos(topo, p);
                }
            }
            case C_VOLTAR -> {
                clique(p);
                abrirPrincipal(p, p);
            }
            default -> { }
        }
    }

    @EventHandler
    public void aoArrastar(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder(false) instanceof Menu) e.setCancelled(true);
    }

    // =====================================================================
    //  Digitar a tag no chat
    // =====================================================================

    @EventHandler(priority = EventPriority.LOWEST)
    public void aoFalar(AsyncChatEvent e) {
        Player p = e.getPlayer();
        Long expira = esperandoTag.remove(p.getUniqueId());
        if (expira == null || System.currentTimeMillis() > expira) return;

        e.setCancelled(true); // a mensagem não vai para o chat público
        String texto = PlainTextComponentSerializer.plainText().serialize(e.message());

        // O chat roda em outra thread; volta para a thread principal para mexer no jogo.
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            if (texto.equalsIgnoreCase("cancelar")) {
                p.sendMessage(Component.text("Troca de tag cancelada.", NamedTextColor.GRAY));
            } else {
                String erro = plugin.tags().aplicarTagDigitada(p, texto);
                if (erro != null) {
                    erro(p, erro);
                } else {
                    p.sendMessage(Component.text("Tag alterada! ", NamedTextColor.GREEN)
                            .append(LegacyComponentSerializer.legacyAmpersand().deserialize(plugin.tags().getTag(p))));
                    p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.6f, 2f);
                }
            }
            abrirCosmeticos(p);
        });
    }

    /** Fecha os menus abertos (usado ao desligar o plugin). */
    public void fecharTodos() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder(false) instanceof Menu) p.closeInventory();
        }
    }

    @EventHandler
    public void aoSair(PlayerQuitEvent e) {
        esperandoTag.remove(e.getPlayer().getUniqueId());
    }

    // =====================================================================
    //  Itens
    // =====================================================================

    private ItemStack iconeSkill(Player alvo, Skill s, int max) {
        StatsManager st = plugin.stats();
        int nivel = st.getNivel(alvo, s);
        boolean noMax = nivel >= max;
        double prog = st.progresso(alvo, s);

        List<Component> lore = new ArrayList<>();
        lore.add(linha("Nível ", NamedTextColor.GRAY, nivel + " / " + max, NamedTextColor.WHITE));
        lore.add(barra(prog).append(Component.text(" " + Math.round(prog * 100) + "%", NamedTextColor.GRAY)));
        if (noMax) {
            lore.add(Component.text("★ Nível máximo!", NamedTextColor.GOLD));
        } else {
            double xp = st.getXp(alvo, s);
            double dentro = xp - st.xpTotalParaNivel(nivel);
            lore.add(linha("XP: ", NamedTextColor.GRAY,
                    StatsManager.fmt(Math.floor(dentro)) + " / " + StatsManager.fmt(Math.ceil(st.xpParaProximo(nivel))),
                    NamedTextColor.YELLOW));
        }
        lore.add(Component.empty());
        lore.add(Component.text("Bônus atual:", NamedTextColor.GRAY));
        lore.add(Component.text(" " + (nivel == 0 ? "nenhum ainda" : plugin.bonus().descricao(s, nivel)), NamedTextColor.GREEN));
        if (!noMax) {
            lore.add(Component.text("No nível " + (nivel + 1) + ":", NamedTextColor.GRAY));
            lore.add(Component.text(" " + plugin.bonus().descricao(s, nivel + 1), NamedTextColor.DARK_GREEN));
        }
        lore.add(Component.empty());
        lore.add(Component.text("Como evoluir:", NamedTextColor.GRAY));
        lore.add(Component.text(" " + s.comoEvoluir(), NamedTextColor.WHITE));

        ItemStack icone = new ItemStack(s.material());
        return enfeitar(icone, Component.text(s.icone() + " " + s.nome(), s.cor(), TextDecoration.BOLD), lore, noMax);
    }

    private static Component barra(double progresso) {
        int cheios = (int) Math.round(Math.max(0, Math.min(1, progresso)) * 10);
        return Component.text("■".repeat(cheios), NamedTextColor.GREEN)
                .append(Component.text("■".repeat(10 - cheios), NamedTextColor.DARK_GRAY));
    }

    private static Component linha(String rotulo, NamedTextColor corRotulo, String valor, NamedTextColor corValor) {
        return Component.text(rotulo, corRotulo).append(Component.text(valor, corValor));
    }

    private static ItemStack item(Material m, Component nome, List<Component> lore) {
        return enfeitar(new ItemStack(m), nome, lore, false);
    }

    /** Coloca nome, descrição, esconde informações de atributo e opcionalmente faz brilhar. */
    private static ItemStack enfeitar(ItemStack item, Component nome, List<Component> lore, boolean brilhar) {
        item.editMeta(meta -> {
            meta.displayName(nome.decoration(TextDecoration.ITALIC, false));
            meta.lore(semItalico(lore));
            meta.setAttributeModifiers(ImmutableMultimap.of()); // necessário para esconder dano/velocidade
            meta.addItemFlags(ItemFlag.values());
            if (brilhar) meta.setEnchantmentGlintOverride(true);
        });
        return item;
    }

    private static List<Component> semItalico(List<Component> lore) {
        return lore.stream().map(c -> c.decoration(TextDecoration.ITALIC, false)).toList();
    }

    private static void preencherBorda(Inventory inv) {
        ItemStack vidro = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        vidro.editMeta(m -> m.setHideTooltip(true));
        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) inv.setItem(i, vidro);
        }
    }

    private static void clique(Player p) {
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1f);
    }

    private static void erro(Player p, String msg) {
        p.sendMessage(Component.text(msg, NamedTextColor.RED));
        p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1f);
    }
}
