package br.rpgatributos;

import org.bukkit.configuration.file.FileConfiguration;

/** Valores do config.yml já lidos, para não consultar o arquivo a cada evento. */
public final class Settings {

    public final int nivelMaximo;
    public final double xpBase;
    public final double xpExpoente;
    public final double multiplicadorXp;
    public final boolean actionBar;

    public final double minXpPedra, minXpMinerio, minVelocidade, minChanceDupla;
    public final double madXpTronco, madVelocidade, madChanceDupla;
    public final double corXpPorBloco, corVelocidade;
    public final double puloXpPulo, puloXpQueda, puloForca, puloQuedaSegura, puloReducaoQueda, puloReducaoMax;
    public final double comXpMonstro, comXpAnimal, comXpJogador, comMultSpawner, comDano, comVida;

    public final boolean tagMostrarNivel;
    public final int tagTamanhoMax;
    public final double tagAltura;

    public Settings(FileConfiguration c) {
        nivelMaximo = Math.max(1, c.getInt("nivel-maximo", 50));
        xpBase = c.getDouble("xp-base", 20);
        xpExpoente = c.getDouble("xp-expoente", 1.4);
        multiplicadorXp = c.getDouble("multiplicador-xp", 1.0);
        actionBar = c.getBoolean("mostrar-xp-na-actionbar", true);

        minXpPedra = c.getDouble("mineracao.xp-pedra", 1);
        minXpMinerio = c.getDouble("mineracao.xp-minerio", 6);
        minVelocidade = c.getDouble("mineracao.velocidade-por-nivel", 0.02);
        minChanceDupla = c.getDouble("mineracao.chance-dupla-por-nivel", 0.01);

        madXpTronco = c.getDouble("madeira.xp-tronco", 2);
        madVelocidade = c.getDouble("madeira.velocidade-por-nivel", 0.02);
        madChanceDupla = c.getDouble("madeira.chance-dupla-por-nivel", 0.01);

        corXpPorBloco = c.getDouble("corrida.xp-por-bloco", 0.1);
        corVelocidade = c.getDouble("corrida.velocidade-por-nivel", 0.004);

        puloXpPulo = c.getDouble("pulo.xp-por-pulo", 0.5);
        puloXpQueda = c.getDouble("pulo.xp-por-dano-de-queda", 1.0);
        puloForca = c.getDouble("pulo.pulo-por-nivel", 0.006);
        puloQuedaSegura = c.getDouble("pulo.queda-segura-por-nivel", 0.1);
        puloReducaoQueda = c.getDouble("pulo.reducao-dano-queda-por-nivel", 0.01);
        puloReducaoMax = c.getDouble("pulo.reducao-dano-queda-maxima", 0.6);

        comXpMonstro = c.getDouble("combate.xp-monstro", 8);
        comXpAnimal = c.getDouble("combate.xp-animal", 2);
        comXpJogador = c.getDouble("combate.xp-jogador", 15);
        comMultSpawner = c.getDouble("combate.multiplicador-mob-de-spawner", 0.25);
        comDano = c.getDouble("combate.dano-por-nivel", 0.05);
        comVida = c.getDouble("combate.vida-por-nivel", 0.2);

        tagMostrarNivel = c.getBoolean("tag.mostrar-nivel", true);
        tagTamanhoMax = c.getInt("tag.tamanho-maximo", 32);
        tagAltura = c.getDouble("tag.altura-extra", 0.3);
    }
}
