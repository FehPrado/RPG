package br.rpgatributos;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Todos os comandos do plugin: /atributos, /rpgadmin, /chapeu e /tag. */
public final class Comandos implements TabExecutor {

    private final RPGAtributos plugin;

    public Comandos(RPGAtributos plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "atributos" -> atributos(sender, args);
            case "rpgadmin" -> admin(sender, args);
            case "chapeu" -> chapeu(sender, args);
            case "tag" -> tag(sender, args);
            case "cosmeticos" -> {
                if (sender instanceof Player p) plugin.menus().abrirCosmeticos(p);
                else erro(sender, "Só jogadores.");
            }
            default -> { return false; }
        }
        return true;
    }

    private static void erro(CommandSender s, String msg) {
        s.sendMessage(Component.text(msg, NamedTextColor.RED));
    }

    private static void ok(CommandSender s, String msg) {
        s.sendMessage(Component.text(msg, NamedTextColor.GREEN));
    }

    // ================= /atributos =================

    private void atributos(CommandSender sender, String[] args) {
        Player alvo;
        if (args.length >= 1) {
            if (!sender.hasPermission("rpg.atributos.outros")) { erro(sender, "Sem permissão."); return; }
            alvo = Bukkit.getPlayerExact(args[0]);
            if (alvo == null) { erro(sender, "Jogador não encontrado (precisa estar online)."); return; }
        } else if (sender instanceof Player p) {
            alvo = p;
        } else {
            erro(sender, "Use: /atributos <jogador>");
            return;
        }

        // Jogador vê o menu; "/atributos <jogador> chat" ou o console veem no chat.
        boolean noChat = args.length >= 2 && args[1].equalsIgnoreCase("chat");
        if (sender instanceof Player quemVe && !noChat) {
            plugin.menus().abrirPrincipal(quemVe, alvo);
            return;
        }

        StatsManager st = plugin.stats();
        int max = plugin.settings().nivelMaximo;

        sender.sendMessage(Component.text("━━━━━ ", NamedTextColor.DARK_GRAY)
                .append(Component.text("Atributos de " + alvo.getName(), NamedTextColor.GOLD).decorate(TextDecoration.BOLD))
                .append(Component.text(" ━━━━━", NamedTextColor.DARK_GRAY)));

        for (Skill s : Skill.values()) {
            int nivel = st.getNivel(alvo, s);
            double prog = st.progresso(alvo, s);
            sender.sendMessage(Component.text(s.icone() + " " + s.nome(), s.cor())
                    .append(Component.text("  Nv " + nivel + (nivel >= max ? " (MÁX)" : ""), NamedTextColor.WHITE))
                    .append(Component.text("  ")).append(barra(prog))
                    .append(Component.text(" " + Math.round(prog * 100) + "%", NamedTextColor.GRAY)));
            sender.sendMessage(Component.text("   " + plugin.bonus().descricao(s, nivel), NamedTextColor.DARK_GRAY));
        }
        sender.sendMessage(Component.text("Nível total: " + st.nivelTotal(alvo), NamedTextColor.YELLOW));
    }

    private static Component barra(double progresso) {
        int cheios = (int) Math.round(progresso * 10);
        return Component.text("■".repeat(cheios), NamedTextColor.GREEN)
                .append(Component.text("■".repeat(10 - cheios), NamedTextColor.DARK_GRAY));
    }

    // ================= /rpgadmin =================

    private void admin(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(Component.text("""
                    /rpgadmin set <jogador> <atributo> <nível>
                    /rpgadmin addxp <jogador> <atributo> <xp>
                    /rpgadmin reset <jogador> [atributo]
                    /rpgadmin reload""", NamedTextColor.YELLOW));
            return;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            plugin.recarregar();
            ok(sender, "Config recarregada.");
            return;
        }
        if (args.length < 2) { erro(sender, "Informe o jogador."); return; }
        Player alvo = Bukkit.getPlayerExact(args[1]);
        if (alvo == null) { erro(sender, "Jogador não encontrado (precisa estar online)."); return; }
        StatsManager st = plugin.stats();

        switch (sub) {
            case "set", "addxp" -> {
                if (args.length < 4) { erro(sender, "Faltam argumentos."); return; }
                Skill s = Skill.porId(args[2]);
                if (s == null) { erro(sender, "Atributo inválido. Use: " + nomesSkills()); return; }
                double valor;
                try { valor = Double.parseDouble(args[3]); } catch (NumberFormatException ex) { erro(sender, "Número inválido."); return; }
                if (sub.equals("set")) {
                    int nivel = (int) Math.max(0, Math.min(valor, plugin.settings().nivelMaximo));
                    st.setXp(alvo, s, st.xpTotalParaNivel(nivel));
                    ok(sender, alvo.getName() + " agora tem " + s.nome() + " nível " + nivel + ".");
                } else {
                    st.darXp(alvo, s, valor / plugin.settings().multiplicadorXp);
                    ok(sender, "XP adicionado.");
                }
            }
            case "reset" -> {
                if (args.length >= 3) {
                    Skill s = Skill.porId(args[2]);
                    if (s == null) { erro(sender, "Atributo inválido."); return; }
                    st.setXp(alvo, s, 0);
                } else {
                    for (Skill s : Skill.values()) st.setXp(alvo, s, 0);
                }
                ok(sender, "Atributos de " + alvo.getName() + " resetados.");
            }
            default -> { erro(sender, "Subcomando desconhecido."); return; }
        }
        plugin.bonus().aplicar(alvo);
        plugin.tags().atualizarTexto(alvo);
    }

    private static String nomesSkills() {
        return String.join(", ", Arrays.stream(Skill.values()).map(Skill::id).toList());
    }

    // ================= /chapeu =================

    private void chapeu(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) { erro(sender, "Só jogadores."); return; }
        boolean tirar = args.length >= 1 && (args[0].equalsIgnoreCase("tirar") || args[0].equalsIgnoreCase("remover"));
        if (!tirar && p.getInventory().getItemInMainHand().isEmpty()) {
            erro(sender, "Segure o item que quer colocar na cabeça (ou use /cosmeticos).");
            return;
        }
        Chapeu.Resultado r = tirar ? Chapeu.tirar(p) : Chapeu.colocar(p, p.getInventory().getHeldItemSlot());
        if (r.ok()) ok(sender, r.mensagem() + (tirar ? "" : " (/chapeu tirar para remover)"));
        else erro(sender, r.mensagem());
    }

    // ================= /tag =================

    private void tag(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) { erro(sender, "Só jogadores."); return; }
        if (args.length == 0) {
            sender.sendMessage(Component.text("Use: /tag <texto>  (cores com &, ex: &6Rei &fdo Minério)  |  /tag remover", NamedTextColor.YELLOW));
            return;
        }
        if (args.length == 1 && (args[0].equalsIgnoreCase("remover") || args[0].equalsIgnoreCase("reset"))) {
            plugin.tags().setTag(p, null);
            ok(sender, "Tag removida.");
            return;
        }

        String falha = plugin.tags().aplicarTagDigitada(p, String.join(" ", args));
        if (falha != null) { erro(sender, falha); return; }
        ok(sender, "Tag alterada! Os outros jogadores já estão vendo.");
    }

    // ================= tab complete =================

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> op = new ArrayList<>();
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "atributos" -> {
                if (args.length == 1) return null; // null = nomes de jogadores
                if (args.length == 2) op.add("chat");
            }
            case "chapeu" -> { if (args.length == 1) op.add("tirar"); }
            case "tag" -> { if (args.length == 1) op.add("remover"); }
            case "rpgadmin" -> {
                if (args.length == 1) op.addAll(List.of("set", "addxp", "reset", "reload"));
                else if (args.length == 2 && !args[0].equalsIgnoreCase("reload")) return null;
                else if (args.length == 3) for (Skill s : Skill.values()) op.add(s.id());
            }
            default -> { }
        }
        String ultimo = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        op.removeIf(s -> !s.startsWith(ultimo));
        return op;
    }
}
