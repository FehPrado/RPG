package br.rpgatributos;

import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Statistic;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Escuta o que o jogador faz e transforma em XP. */
public final class SkillListener implements Listener {

    private static final int LIMITE_BLOCOS_COLOCADOS = 50_000;

    private final RPGAtributos plugin;

    /** Blocos colocados por jogadores: quebrar eles não dá XP (evita farm de colocar/quebrar). */
    private final Set<String> colocados = new LinkedHashSet<>();
    /** Blocos quebrados naturalmente que podem dar drop duplo. */
    private final Set<String> podeDuplicar = new HashSet<>();
    /** Último valor da estatística de corrida de cada jogador. */
    private final Map<UUID, Integer> ultimaCorrida = new HashMap<>();

    public SkillListener(RPGAtributos plugin) {
        this.plugin = plugin;
    }

    private StatsManager stats() { return plugin.stats(); }
    private Settings cfg() { return plugin.settings(); }

    private static String chave(Block b) {
        return b.getWorld().getName() + ":" + b.getX() + ":" + b.getY() + ":" + b.getZ();
    }

    private static boolean ehMinerio(Material m) {
        return m.name().endsWith("_ORE");
    }

    private static boolean contaXp(Player p) {
        return p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE;
    }

    // ---------------- entrar / sair ----------------

    @EventHandler
    public void aoEntrar(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.bonus().aplicar(p);
        ultimaCorrida.put(p.getUniqueId(), p.getStatistic(Statistic.SPRINT_ONE_CM));
    }

    @EventHandler
    public void aoSair(PlayerQuitEvent e) {
        ultimaCorrida.remove(e.getPlayer().getUniqueId());
    }

    // ---------------- mineração e madeira ----------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void aoColocar(BlockPlaceEvent e) {
        colocados.add(chave(e.getBlockPlaced()));
        if (colocados.size() > LIMITE_BLOCOS_COLOCADOS) {
            colocados.remove(colocados.iterator().next()); // descarta o mais antigo
        }
    }

    /** Quando o jogador começa a quebrar, ajusta a velocidade conforme o tipo de bloco. */
    @EventHandler(ignoreCancelled = true)
    public void aoComecarQuebrar(BlockDamageEvent e) {
        Player p = e.getPlayer();
        Material tipo = e.getBlock().getType();
        double bonus = 0;
        if (Tag.LOGS.isTagged(tipo)) {
            bonus = stats().getNivel(p, Skill.MADEIRA) * cfg().madVelocidade;
        } else if (Tag.MINEABLE_PICKAXE.isTagged(tipo)) {
            bonus = stats().getNivel(p, Skill.MINERACAO) * cfg().minVelocidade;
        }
        plugin.bonus().definirVelocidadeQuebra(p, bonus);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void aoQuebrar(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlock();
        String k = chave(b);
        boolean foiColocado = colocados.remove(k);
        if (foiColocado || !contaXp(p)) return;

        Material tipo = b.getType();
        if (Tag.LOGS.isTagged(tipo)) {
            stats().darXp(p, Skill.MADEIRA, cfg().madXpTronco);
            marcarDuplicavel(k);
        } else if (ehMinerio(tipo)) {
            stats().darXp(p, Skill.MINERACAO, cfg().minXpMinerio);
            marcarDuplicavel(k);
        } else if (Tag.MINEABLE_PICKAXE.isTagged(tipo)) {
            stats().darXp(p, Skill.MINERACAO, cfg().minXpPedra);
        }
    }

    private void marcarDuplicavel(String k) {
        podeDuplicar.add(k);
        // O drop acontece no mesmo tick; limpa depois por segurança.
        plugin.getServer().getScheduler().runTask(plugin, () -> podeDuplicar.remove(k));
    }

    /** Chance de drop em dobro para minérios e troncos. */
    @EventHandler(ignoreCancelled = true)
    public void aoDropar(BlockDropItemEvent e) {
        if (!podeDuplicar.remove(chave(e.getBlock()))) return;
        Player p = e.getPlayer();
        Material tipo = e.getBlockState().getType();

        double chance;
        if (Tag.LOGS.isTagged(tipo)) {
            chance = stats().getNivel(p, Skill.MADEIRA) * cfg().madChanceDupla;
        } else if (ehMinerio(tipo)) {
            chance = stats().getNivel(p, Skill.MINERACAO) * cfg().minChanceDupla;
        } else {
            return;
        }
        if (ThreadLocalRandom.current().nextDouble() >= chance) return;

        boolean duplicou = false;
        Location loc = e.getBlock().getLocation().add(0.5, 0.5, 0.5);
        for (Item item : e.getItems()) {
            ItemStack stack = item.getItemStack();
            // Com Toque Suave o minério dropa ele mesmo: não duplica para não virar exploit.
            if (ehMinerio(tipo) && stack.getType() == tipo) continue;
            loc.getWorld().dropItemNaturally(loc, stack.clone());
            duplicou = true;
        }
        if (duplicou) {
            loc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 8, 0.3, 0.3, 0.3);
            p.playSound(loc, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.6f);
        }
    }

    // ---------------- pulo e queda ----------------

    @EventHandler(ignoreCancelled = true)
    public void aoPular(PlayerJumpEvent e) {
        if (contaXp(e.getPlayer())) {
            stats().darXp(e.getPlayer(), Skill.PULO, cfg().puloXpPulo);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void aoCair(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(e.getEntity() instanceof Player p) || !contaXp(p)) return;
        stats().darXp(p, Skill.PULO, e.getFinalDamage() * cfg().puloXpQueda);
    }

    // ---------------- combate ----------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void aoMatar(EntityDeathEvent e) {
        LivingEntity morto = e.getEntity();
        Player p = morto.getKiller();
        if (p == null || p == morto || !contaXp(p)) return;

        double xp;
        if (morto instanceof Player) xp = cfg().comXpJogador;
        else if (morto instanceof Enemy) xp = cfg().comXpMonstro;
        else xp = cfg().comXpAnimal;

        if (morto.getEntitySpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER) {
            xp *= cfg().comMultSpawner;
        }
        stats().darXp(p, Skill.COMBATE, xp);
    }

    // ---------------- corrida (roda 1x por segundo) ----------------

    public void verificarCorrida() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            int agora = p.getStatistic(Statistic.SPRINT_ONE_CM);
            Integer antes = ultimaCorrida.put(p.getUniqueId(), agora);
            if (antes == null || agora <= antes || !contaXp(p)) continue;
            double blocos = (agora - antes) / 100.0;
            stats().darXp(p, Skill.CORRIDA, blocos * cfg().corXpPorBloco);
        }
    }
}
