package br.rpgatributos;

import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class RPGAtributos extends JavaPlugin {

    private Settings settings;
    private StatsManager stats;
    private BonusManager bonus;
    private TagManager tags;
    private SkillListener skillListener;
    private MenuManager menus;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = new Settings(getConfig());
        stats = new StatsManager(this);
        bonus = new BonusManager(this);
        tags = new TagManager(this);
        skillListener = new SkillListener(this);
        menus = new MenuManager(this);

        getServer().getPluginManager().registerEvents(skillListener, this);
        getServer().getPluginManager().registerEvents(tags, this);
        getServer().getPluginManager().registerEvents(menus, this);

        Comandos comandos = new Comandos(this);
        for (String nome : new String[]{"atributos", "rpgadmin", "chapeu", "tag", "cosmeticos"}) {
            PluginCommand c = getCommand(nome);
            if (c != null) {
                c.setExecutor(comandos);
                c.setTabCompleter(comandos);
            }
        }

        // Corrida: confere a distância corrida 1x por segundo.
        getServer().getScheduler().runTaskTimer(this, skillListener::verificarCorrida, 20L, 20L);
        // Tags: seguem o jogador a cada tick.
        getServer().getScheduler().runTaskTimer(this, tags::tick, 1L, 1L);

        // Caso o plugin seja carregado com gente online (/reload).
        for (Player p : getServer().getOnlinePlayers()) {
            bonus.aplicar(p);
            tags.garantir(p);
        }
        getLogger().info("RPGAtributos ativado!");
    }

    @Override
    public void onDisable() {
        if (menus != null) menus.fecharTodos();
        if (tags != null) tags.removerTodos();
    }

    public void recarregar() {
        reloadConfig();
        settings = new Settings(getConfig());
        for (Player p : getServer().getOnlinePlayers()) {
            bonus.aplicar(p);
            tags.garantir(p);
            tags.atualizarTexto(p);
        }
    }

    public Settings settings() { return settings; }
    public StatsManager stats() { return stats; }
    public BonusManager bonus() { return bonus; }
    public TagManager tags() { return tags; }
    public MenuManager menus() { return menus; }
}
