package br.rpgatributos;

import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Material;

import java.util.Locale;

/** Os atributos que o jogador evolui usando. */
public enum Skill {
    MINERACAO("mineracao", "Mineração", "⛏", NamedTextColor.GRAY, Material.IRON_PICKAXE,
            "Quebre pedras e minérios com picareta."),
    MADEIRA("madeira", "Corte de Madeira", "♣", NamedTextColor.GOLD, Material.IRON_AXE,
            "Corte troncos de árvore."),
    CORRIDA("corrida", "Corrida", "»", NamedTextColor.AQUA, Material.LEATHER_BOOTS,
            "Corra (sprint) pelo mundo."),
    PULO("pulo", "Pulo e Queda", "⬆", NamedTextColor.GREEN, Material.FEATHER,
            "Pule e sobreviva a quedas."),
    COMBATE("combate", "Combate", "⚔", NamedTextColor.RED, Material.IRON_SWORD,
            "Derrote monstros, animais e jogadores.");

    private final String id;
    private final String nome;
    private final String icone;
    private final TextColor cor;
    private final Material material;
    private final String comoEvoluir;

    Skill(String id, String nome, String icone, TextColor cor, Material material, String comoEvoluir) {
        this.id = id;
        this.nome = nome;
        this.icone = icone;
        this.cor = cor;
        this.material = material;
        this.comoEvoluir = comoEvoluir;
    }

    public String id() { return id; }
    public String nome() { return nome; }
    public String icone() { return icone; }
    public TextColor cor() { return cor; }
    public Material material() { return material; }
    public String comoEvoluir() { return comoEvoluir; }

    public static Skill porId(String texto) {
        String t = texto.toLowerCase(Locale.ROOT);
        for (Skill s : values()) {
            if (s.id.equals(t) || s.name().equalsIgnoreCase(t)) return s;
        }
        return null;
    }
}
